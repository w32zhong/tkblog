#include <QPushButton>
#include <QFont>
#include <QLabel>
#include <QComboBox>
#include <QGridLayout>
#include <QTextEdit>

class UI2440 : public QObject
{
	Q_OBJECT

public slots:

	void CmdHandler();

private:
	int lines;
	QApplication *pApp;
	QWidget frame_w;
	QGridLayout layout;
	QFont	font;
	QLabel  label;
	QPushButton quit_b;
	QComboBox combo;
	QString text;
	//QTextEdit TextShow;
	
	void Say(QString &);
	void RemoveOneLine();

public:
	
	UI2440(QApplication*);
};
