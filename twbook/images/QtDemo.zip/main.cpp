#include <QApplication>
#include <QSize>
#include <stdio.h>
#include "head.h"
#include <QScrollBar>

void UI2440::CmdHandler()
{
	QString say = "please select an valid item.\n";

	switch( combo.currentIndex() )
	{
	case 0:
		break;
	case 1:
		say = "Hello\n";
		break;
	case 2:
		say = "quit\n";
		break;
		pApp->quit();
	}
		
	Say(say);
}

void UI2440::RemoveOneLine()
{
	QChar qch;
	int ch;
	int cont = 0;
	for(int i=0; i <= text.length(); i++)
	{
		qch = text[i].toAscii();
		ch = qch.toAscii();
		cont ++;
		if( char(ch) == '\n' )
			break;
	}

	text.remove(0,cont);
	lines --;
}

void UI2440::Say(QString & saying)
{
	QChar qch;
	int ch;
	for(int i=0; i <= saying.length(); i++)
	{
		qch = saying[i].toAscii();
		ch = qch.toAscii();
		if( char(ch) == '\n' )
		{
			lines ++;
		}
	}

	while( lines > 12 )
	{
		RemoveOneLine();
	}

	text += saying;

	text.chop(1);
	char buff[128];
	sprintf(buff , ",lines=%d \n", lines);
	text += buff;

	label.setText(text);
}

UI2440::UI2440(QApplication* pQapp)
{
	lines = 0;
	pApp = pQapp;

	font.setFamily("Times");
	font.setBold(1);
	font.setPointSize(25);

	label.setFont(font);
	label.setAlignment(Qt::AlignTop | Qt::AlignLeft);

	font.setPointSize(36);
	quit_b.setFont(font);
	quit_b.setText(" -> ");
	quit_b.setSizePolicy(QSizePolicy::Minimum,
			QSizePolicy::Fixed);
	connect(&quit_b , SIGNAL(clicked()) ,
			this , SLOT(CmdHandler()) );

	combo.insertItem(0, "select...");
	combo.insertItem(1, "echo hello");
	combo.insertItem(2, "exit the program");
	combo.setMaxVisibleItems(6);
	combo.setFont(font);
	combo.setSizeAdjustPolicy(QComboBox::AdjustToContentsOnFirstShow);
	combo.setSizePolicy(QSizePolicy::Expanding,
			QSizePolicy::Minimum);

	layout.addWidget(&label,2,1,3,4);
	layout.addWidget(&quit_b,1,4,1,1);
	layout.addWidget(&combo,1,1,1,3);

	frame_w.setCursor(QCursor(Qt::BlankCursor));
	frame_w.setLayout(&layout);
	frame_w.showFullScreen(); //->show();
}

int main(int argc, char *argv[])
{
	QApplication app(argc, argv);

	UI2440 ui(&app);

	return app.exec();
}
